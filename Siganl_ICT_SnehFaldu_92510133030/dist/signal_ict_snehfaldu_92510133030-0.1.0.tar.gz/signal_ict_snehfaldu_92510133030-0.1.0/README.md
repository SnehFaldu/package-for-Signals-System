# signal_ICT_SnehFaldu_92510133030

A beginner package for generating basic signals (unit step, impulse, ramp, sine, cosine, exponential)
and performing simple operations (time shift, scale, add, multiply).

This package provides:
1. Unitary signals: unit step, impulse, ramp
2. Trigonometric signals: sine, cosine, exponential
3. Operations: time shift, scaling, addition, multiplication


## Usage
Run the demo:
